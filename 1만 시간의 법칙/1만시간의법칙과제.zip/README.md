# FrontendSchool_3

멋쟁이사자처럼 프론트엔드스쿨 3기 TIL (Today I learned)

<!-- 피그마(디자인)보고 구현  -->

https://www.figma.com/file/YIoHn24LhFrCBEedo96rx6/1%EB%A7%8C-%EC%8B%9C%EA%B0%84%EC%9D%98-%EB%B2%95%EC%B9%99?node-id=2%3A202
